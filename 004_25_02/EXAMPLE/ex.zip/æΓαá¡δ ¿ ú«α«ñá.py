# Создадим пустой словать Capitals
Capitals = dict()

# Заполним его несколькими значениями
Capitals['Россия'] = 'Москва'
Capitals['Украина'] = 'Киев'
Capitals['США'] = 'Вашингтон'

Countries = ['Россия', 'Франция', 'США', 'Украина']

# Добавим элементы словаря
Capitals['Испания'] = 'Мадрид'
Countries.append("Испания")
print(Countries)

for country in Countries:
    # Для каждой страны из списка проверим, есть ли она в словаре Capitals
    if country in Capitals:
        print('Столица страны ' + country + ': ' + Capitals[country])
    else:
        print('В базе нет страны c названием ' + country)

# Все ключи
print(Capitals.keys())

# Все ключи и значения
for key, val in Capitals.items():
    print(key, val)