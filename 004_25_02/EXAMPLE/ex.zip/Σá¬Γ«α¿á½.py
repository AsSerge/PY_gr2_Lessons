x = int(input())
k = 1
s = 0
for i in range(1,x+1):
    k = k*i
    s = s+k
print("Сумма факториалов =", s)
