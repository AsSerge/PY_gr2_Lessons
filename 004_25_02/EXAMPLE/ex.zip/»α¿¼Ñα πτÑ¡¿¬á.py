x = int(input())
y = int(input())
z = int(input())
if x < (y + z):
if y < (x + z):
if z < (x + y):
print('Треугольник с такими параметрами существует')
else: 
print('Треугольник с такими параметрами не существует')
