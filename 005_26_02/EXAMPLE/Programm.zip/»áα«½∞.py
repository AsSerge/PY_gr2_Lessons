print("Задайте пароль")
parol = input()
def ask_password():
    for i in range(0, 3):
        print("Введите пароль")
        s = input()
        if s == parol:
            print('Пароль принят')
            break
        elif i == 2:
            print('В доступе отказано')


ask_password()       
            

