def print_average(arr):
    if not arr:
        print(0)
    else:
        print(sum(arr) / len(arr))
        
        
arr = [1,2,3,4,5,6,7,8]
print_average(arr)