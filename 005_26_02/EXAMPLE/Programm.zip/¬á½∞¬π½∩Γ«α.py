def arithmetic_operation(operation):
    if operation == '+':
        print (a + b)
    elif operation == '-':
        print (a - b)
    elif operation == '*':
        print (a * b)
    elif operation == '/':
        print (a / b)
    
    
a = float(input())
znak = input()
b = float(input())
arithmetic_operation(znak)